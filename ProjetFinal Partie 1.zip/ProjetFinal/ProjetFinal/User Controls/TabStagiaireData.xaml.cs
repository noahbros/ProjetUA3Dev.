﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjetFinal.User_Controls
{
    /// <summary>
    /// Interaction logic for TabStagiaireData.xaml
    /// </summary>
    public partial class TabStagiaireData : UserControl
    {
        public TabStagiaireData()
        {
            InitializeComponent();
        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Your event handling code goes here
            // You can handle the selection change in the ListView here
        }


        private void Btn_AugmenteNumEtudiant_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Btn_DecrementeNumEtudiant_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Btn_Ajouter_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Btn_Effacer_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
